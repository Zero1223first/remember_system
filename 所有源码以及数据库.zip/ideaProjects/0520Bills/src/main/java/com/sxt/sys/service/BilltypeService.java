package com.sxt.sys.service;

import com.sxt.sys.domain.Billtype;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author pzq
 * @since 2025-09-18
 */
public interface BilltypeService extends IService<Billtype> {

}
