package com.sxt.sys.mapper;

import com.sxt.sys.domain.Billtype;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author pzq
 * @since 2025-09-18
 */
public interface BilltypeMapper extends BaseMapper<Billtype> {

}
